package impl;

public class NodoPrioridad {
    int info;
    int prioridad;
    NodoPrioridad sig;

}
