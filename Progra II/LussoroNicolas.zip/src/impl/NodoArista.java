package impl;

public class NodoArista {
    int etiqueta;
    NodoGrafo nodoDestino;
    NodoArista sigArista;
}
