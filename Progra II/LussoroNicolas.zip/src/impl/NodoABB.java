package impl;

import api.ABBTDA;

public class NodoABB {
    int info;
    ABBTDA hijoIzq;
    ABBTDA hijoDer;
}
