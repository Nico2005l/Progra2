package impl;

public class NodoLibro {

    int id;
    String autor;
    String titulo;
    int año;
    NodoLibro sig;

}
