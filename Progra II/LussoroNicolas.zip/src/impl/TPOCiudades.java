package impl;

import api.ConjuntoTDA;
import api.GrafoTDA;
import api.ListaTDA;
import api.TPOCiudadesTDA;

public class TPOCiudades implements TPOCiudadesTDA {

    GrafoTDA miGrafo;

    String [] provincias = {"Buenos Aires","Cordoba","Chubut","Salta"};

    DiccionarioSimpleEstatico ciudadesAnumero;

    DiccionarioSimpleEstatico numeroAciudades;

    ListaTDA ciudades;

    int contVert;

    

    @Override
    public void ListarProvincias() {
        for (String provincia : provincias) {
            System.out.println(provincia);
        }
    }

    @Override
    public void ListarCiudades() {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        while(!conjuntoCiudades.ConjuntoVacio()){
            String ciudad = conjuntoCiudades.Elegir();

            System.out.println(ciudad);

            conjuntoCiudades.Sacar(ciudad);
        }
    }

    @Override
    public void AgregarCiudades(String x) {

        if (!CiudadExistente(x)){
            ciudadesAnumero.Agregar
        }
        miGrafo.AgregarVertice(x);
    }

    @Override
    public void EliminarCiudades(String x) {
        miGrafo.EliminarVertice(x);
    }

    @Override
    public void CiudadesVecinas(String x) {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        while(!conjuntoCiudades.ConjuntoVacio()){
            String ciudad = conjuntoCiudades.Elegir();

            if (miGrafo.ExisteArista(x, ciudad))
                System.out.println(ciudad);

            conjuntoCiudades.Sacar(ciudad);
    }

    @Override
    public void ListarCiudadesPuente(String x, String y) {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        while(!conjuntoCiudades.ConjuntoVacio()){
            String ciudad = conjuntoCiudades.Elegir();
            
            if (miGrafo.ExisteArista(x, ciudad) && miGrafo.ExisteArista(ciudad, y))
                System.out.print(ciudad + " ");
                System.out.print(miGrafo.PesoArista(x, ciudad)+miGrafo.PesoArista(ciudad, y));
                System.out.println();

            conjuntoCiudades.Sacar(ciudad);
    }

    @Override
    public void ListarCiudadesPredecesoras(String x) {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        while(!conjuntoCiudades.ConjuntoVacio()){
            String ciudad = conjuntoCiudades.Elegir();

            if (miGrafo.ExisteArista(ciudad, x))
                System.out.println(ciudad);

            conjuntoCiudades.Sacar(ciudad);
    }

    @Override
    public void ListarCiudadesExtremo() {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        boolean band;
        
        while(!conjuntoCiudades.ConjuntoVacio()){
            band = true;
            String ciudad = conjuntoCiudades.Elegir();
            ConjuntoTDA conjuntoCiudades2 = miGrafo.Vertices();

            while(!conjuntoCiudades2.ConjuntoVacio()){

                String ciudad2 = conjuntoCiudades2.Elegir();

                if (miGrafo.ExisteArista(ciudad, ciudad2)){
                    band=false;
                }
                conjuntoCiudades2.Sacar(ciudad2);
            }
            if (band){
                System.out.println(ciudad);
            }
            conjuntoCiudades.Sacar(ciudad);
    }

    @Override
    public void ListarCiudadesFuertementeConectadas() {
        ConjuntoTDA conjuntoCiudades = miGrafo.Vertices();
        boolean band;
        
        while(!conjuntoCiudades.ConjuntoVacio()){
            String ciudad = conjuntoCiudades.Elegir();
            ConjuntoTDA conjuntoCiudades2 = miGrafo.Vertices();

            while(!conjuntoCiudades2.ConjuntoVacio()){

                String ciudad2 = conjuntoCiudades2.Elegir();

                if (miGrafo.ExisteArista(ciudad, ciudad2) && miGrafo.ExisteArista(ciudad2, ciudad)){
                    System.out.println(ciudad+"esta fuertemente conectada con " + ciudad2);
                }
                conjuntoCiudades2.Sacar(ciudad2);
            }
           
            conjuntoCiudades.Sacar(ciudad);
    }

    @Override
    public int CalcularCamino(String x, String y) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'CalcularCamino'");
    }

    @Override
    public void Inicializar() {
        miGrafo.InicializarGrafo();
        ciudadesAnumero.InicializarDiccionario();
        numeroAciudades.InicializarDiccionario();
    }

    private boolean CiudadExistente (String ciudad){
        
    }

}
