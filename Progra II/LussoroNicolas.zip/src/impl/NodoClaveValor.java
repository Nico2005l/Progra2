package impl;

public class NodoClaveValor {
    int clave;
    int valor;
    NodoClaveValor sig;
}