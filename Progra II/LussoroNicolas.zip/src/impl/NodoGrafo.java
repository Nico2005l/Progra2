package impl;

public class NodoGrafo {

    int nodo;
    NodoArista arista;
    NodoGrafo sigNodo;

}
