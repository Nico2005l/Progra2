package impl;

public class NodoReserva {

    int idReserva;
    int idPasajero;
    int nroVuelo;
    int nroAsiento;
    int Fecha;
    NodoReserva sig;

}
