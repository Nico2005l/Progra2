package impl;

import api.ConjuntoTDA;

public class NodoClaveValorMultiple {
    int clave;
    ConjuntoTDA conjuntoValor;
    NodoClaveValorMultiple sig;

}
