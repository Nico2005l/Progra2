import java.util.Arrays;

import impl.Nodo;

public class ayudin {
   
    // id conjunto, relacion 1:1 1:n diccionario, ordenar colaprio, fifo cola, lifo pila
        
    }

    /* para añadir al final
    
    Nodo aux = new Nodo();
    if (this.ColaVacia()){
        aux.info = x;
        primero=aux;
        ultimo = aux;
    }else{
        aux.info= x;
        ultimo.sig =aux;
        ultimo=aux;
    }*/

    /*para añadir al inicio

        Nodo aux = new Nodo();
        aux.info = x;
        aux.sig = primero;
        primero = aux;
    */
    /* para borrar un elemento

    Nodo aux = primero;
    if(primero.info == info){
        primero = primero.sig;
    }else{
    while (aux.sig.sig != null && aux.sig.info != info ){
        aux = aux.sig;
    }
    aux.sig = aux.sig.sig;
    }
    */
    
    /* para borrar todos los que coincidan
        
        Nodo aux = primero;
        if(aux.info == x){
            primero = primero.sig;
        }
        while (aux.sig.sig!=null){
            while (aux.sig.info != x && aux.sig.sig!=null){
                aux = aux.sig;
            }
            while (aux.sig.info==x){
                aux.sig = aux.sig.sig;
            }
        } 
    */

    // lista dinamica para insert count index recuperar por index




