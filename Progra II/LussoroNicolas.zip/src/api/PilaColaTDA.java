package api;

public interface PilaColaTDA {
    void Inicializar();
    void Cargar(int x);
    void Quitar();
    int Mostrar();
    boolean EstaVacio();
    void Imprimir();
}
